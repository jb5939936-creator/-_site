GitHub Pages 배포:
1) 이 폴더를 새 GitHub 저장소(예: gaeneusam-site)에 업로드
2) Settings → Pages → Source: Deploy from a branch → Branch: main / Folder: /(root)
3) 커스텀 도메인: Pages의 Custom domain에 gaeneusam.com 입력 (CNAME 파일도 포함됨)
4) DNS: 도메인 업체에서 www CNAME → 사용자명.github.io 로 설정 (apex는 ALIAS/ANAME 또는 A 레코드)
